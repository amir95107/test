﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.Entity;
using Test_Order.data;

namespace Test_Order.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private static List<Order> Orders = new List<Order> {
                new Order{ Id = 1,Username ="Amir",Date=DateTime.Now},
                new Order{ Id = 2,Username ="wewe",Date=DateTime.Now},
                new Order{ Id = 3,Username ="Arwerwmir",Date=DateTime.Now},
                new Order{ Id = 4,Username ="wef",Date=DateTime.Now},
                new Order{ Id = 6,Username ="Amebveir",Date=DateTime.Now},
                new Order{ Id = 7,Username ="23r32",Date=DateTime.Now}
            };
        private readonly DataContext _context;

        public OrderController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<List<Order>> Get()
        {
            return Ok (_context.Orders.ToList());
        }
        [HttpGet("{id}")]
        public ActionResult<Order> Get(int id)
        {
            var order = _context.Orders.FirstOrDefault(a => a.Id == id);
            if (order == null)
                return BadRequest("Not Found");
            return Ok(order);
        }
        [HttpPost]
        public ActionResult<List<Order>> Post(Order order)
        {
            _context.Orders.Add(order);
            _context.SaveChanges();
            return Ok(_context.Orders);
        }

        [HttpPut]
        public ActionResult<List<Order>> Update(Order order)
        {
            var _order = _context.Orders.Find(order.Id);
            if (_order == null) return BadRequest("Not Found");

            _order.Username = order.Username;
            _order.Date = DateTime.Now;
            _context.SaveChanges();

            return Ok(_context.Orders);
        }

        [HttpDelete("{id}")]
        public ActionResult<Order> Delete(int id)
        {
            var order = _context.Orders.FirstOrDefault(a => a.Id == id);
            if (order == null)
                return BadRequest("Not Found");

            _context.Orders.Remove(order);
             _context.SaveChanges();

            return Ok(_context.Orders.ToList());
        }
    }
}
